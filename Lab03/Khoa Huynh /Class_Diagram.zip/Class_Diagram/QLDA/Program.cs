﻿
public class ChiNhanh
{
    public string MaCN {
        get;
        set; 
    }
    public string TenCN
    {
        get;
        set; 
    }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public bool IsDeleted { get; set; }

    public string DiaChi {  get; set; }
    public bool TrangThai { get; set; }

    public List<NhanVien> NhanViens { get; set; } = new List<NhanVien>();
    public List<LoHang> LoHangs { get; set; } = new List<LoHang>();
    public List<HoaDon> HoaDons { get; set; } = new List<HoaDon>();
    public List<CaLamViec> CaLamViecs { get; set; } = new List<CaLamViec>();
    public List<InventoryTransaction> Transactions { get; set; } = new List<InventoryTransaction>();


}


public class NhanVien
{
    public string MaNV {get; set;} 

    public string TenNV { get; set;}
    public string ChucVu { get; set; }
    public string UserName { get; set; }
    public string PasswordHash { get; set; }
    public bool TrangThai { get; set; }
    public string MaCN { get; set;}
    public ChiNhanh ChiNhanh {  get; set; }

    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public bool IsDeleted { get; set; }


    public bool DangNhap(string username, string password)
    {
        return UserName == username && PasswordHash == password; 
    }

}

public class PhienBanCongThuc
{
    public string MaVer { get; set; }
    public DateTime NgayHieuLuc { get; set; }
    public bool TrangThai { get; set; }

    public string MaSP { get; set; }
    public SanPham SanPham { get; set; }
    public DateTime CreatedAt { get; set; }

    public List<DinhMucRecipe> DinhMucs { get; set; } = new List<DinhMucRecipe>();
}
public class NguyenLieu
{
    public string MaNL { get; set; }
    public string TenNL { get; set; }
    public string DonViCoBan { get; set; }
    public decimal TonToiThieu { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public bool IsDeleted { get; set; }
    public List<NguyenLieuDonVi> NguyenLieuDonVis { get; set; } = new List<NguyenLieuDonVi>();


    public List<DinhMucRecipe> DinhMucs { get; set; } = new List<DinhMucRecipe>(); 
    public List<InventoryTransaction> Transactions { get; set; } = new List<InventoryTransaction>();

    public List<LoHang> LoHangs { get; set; } = new List<LoHang>();
}
public class DinhMucRecipe
{
    public string MaVer { get; set; }
    public string MaNL { get; set; }
    public decimal SoLuong { get; set; }

    public PhienBanCongThuc PhienBan { get; set; }
    public NguyenLieu NguyenLieu { get; set; }
}

public class SanPham
{
    public string MaSP { get; set;}
    public string TenSP { get; set;}
    public decimal GiaHienTai { get; set; }
    public bool IsTopping { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public bool IsDeleted { get; set; }

    public List<PhienBanCongThuc> PhienBanCongThucs { get; set; } = new List<PhienBanCongThuc>();

}


public class LoHang
{
    public string BatchID { get; set; }
    public string MaNL { get; set; }
    public string MaCN { get; set; }

    public decimal SoLuongCon { get; set; }
    public DateTime HanDung { get; set; }
    public DateTime NgayNhap { get; set; }

    public NguyenLieu NguyenLieu { get; set; }
    public ChiNhanh ChiNhanh { get; set; }
}

public enum LoaiGD
{
    Nhap,
    Xuat,
    BanHang,
    ChuyenKho,
    DieuChinh
}

public enum ReferenceType
{
    HoaDon,
    PhieuNhap,
    PhieuXuat,
    PhieuChuyen,
    KiemKho
}


public class InventoryTransaction
{
    public string MaTrans { get; set; }

    public LoaiGD LoaiGiaoDich { get; set; }
    public decimal SoLuong { get; set; }

    public ReferenceType RefType { get; set; }
    public string? RefID { get; set; }

    public DateTime CreatedAt { get; set; }

    public string MaCN { get; set; }
    public ChiNhanh ChiNhanh { get; set; }

    public string MaNL { get; set; }
    public NguyenLieu NguyenLieu { get; set; }

    public string BatchID { get; set; }
    public LoHang LoHang { get; set; }

    public void GhiNhan()
    {
        // logic ghi log
    }
}

public enum TrangThaiHoaDon
{
    Pending,
    Paid,
    Cancelled
}

public class HoaDon
{
    public string MaHD { get; set; }

    public string MaCN { get; set; }
    public string MaCa { get; set; }


    public TrangThaiHoaDon TrangThai { get; set; }
    public decimal TongTien { get; set; }
    public bool IsSynced { get; set; }
    public DateTime CreatedAt { get; set; }
    public bool IsDeleted { get; set; }



    public List<ChiTietHD> ChiTietHDs { get; set; } = new List<ChiTietHD>();
    public ChiNhanh ChiNhanh { get; set; }
    public CaLamViec CaLamViec { get; set; }
    public List<ThanhToan> ThanhToans { get; set; } = new List<ThanhToan> ();


    public decimal TinhTongTien()
    {
        return ChiTietHDs.Sum(x => x.TinhThanhTien());
    }
}

public class ChiTietHD
{
    public int Id { get; set; }

    public string MaHD { get; set; }
    public HoaDon HoaDon { get; set; }

    public string MaSP { get; set; }
    public string MaVer { get; set; }

    public int SoLuong { get; set; }
    public decimal GiaBan { get; set; }

    public SanPham SanPham { get; set; }
    public PhienBanCongThuc PhienBan { get; set; }

    public decimal TinhThanhTien()
    {
        return SoLuong * GiaBan;
    }
}


public class ThanhToan
{
    public string MaTT { get; set; }
    public string MaHD { get; set; }

    public string PhuongThuc { get; set; }
    public decimal SoTien { get; set; }

    public HoaDon HoaDon { get; set; }
    public DateTime CreatedAt { get; set; }
}


public class DonVi
{
    public string MaDV { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public bool IsDeleted { get; set; }
    public List<NguyenLieuDonVi> NguyenLieuDonVis { get; set; } = new List<NguyenLieuDonVi>();
    public string TenDonVi { get; set; }
}


public class NguyenLieuDonVi
{
    public string MaNL { get; set; }
    public string MaDV { get; set; }
    public bool IsDefault { get; set; }

    public NguyenLieu NguyenLieu { get; set; }
    public DonVi DonVi { get; set; }
    // PK = (MaNL, MaDV)

}

public class QuyDoiDonVi
{
    public string MaDV_From { get; set; }
    public string MaDV_To { get; set; }
    public decimal TyLeQuyDoi { get; set; }
    public DonVi DonViFrom { get; set; }
    public DonVi DonViTo { get; set; }

}

public class CaLamViec
{
    public string MaCa { get; set; }

    public string MaNV { get; set; }
    public string MaCN { get; set; }

    public decimal TienDauCa { get; set; }
    public decimal TienCuoiCa { get; set; }

    public DateTime ThoiGianMo { get; set; }
    public DateTime ThoiGianDong { get; set; }
    public DateTime CreatedAt { get; set; }

    public NhanVien NhanVien { get; set; }
    public ChiNhanh ChiNhanh { get; set; }

    public List<HoaDon> HoaDons { get; set; } = new List<HoaDon>();
}

public class PhieuNhap
{
    public string MaPN { get; set; }

    public string MaCN { get; set; }
    public string MaNV { get; set; }

    public DateTime NgayNhap { get; set; }
    public DateTime CreatedAt { get; set; }
    public bool IsDeleted { get; set; }


    public ChiNhanh ChiNhanh { get; set; }
    public NhanVien NhanVien { get; set; }
    public string MaNCC { get; set; }
    public NhaCungCap NhaCungCap { get; set; }

    public List<ChiTietPhieuNhap> ChiTietPhieuNhaps { get; set; } = new List<ChiTietPhieuNhap>();
}
public class NhaCungCap
{
    public string MaNCC { get; set; } 
    public string TenNCC {  get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public bool IsDeleted { get; set; }

    public List<PhieuNhap> PhieuNhaps { get; set; } = new List<PhieuNhap>();

}
public class ChiTietPhieuNhap
{
    public string MaPN { get; set; }
    public string MaNL { get; set; }
    public string BatchID { get; set; }

    public decimal SoLuong { get; set; }

    public PhieuNhap PhieuNhap { get; set; }
    public NguyenLieu NguyenLieu { get; set; }
    public LoHang LoHang { get; set; }
}
public class PhieuXuat
{
    public string MaPX { get; set; }

    public string MaCN { get; set; }
    public string MaNV { get; set; }

    public string LyDo { get; set; }
    public DateTime CreatedAt { get; set; }
    public bool IsDeleted { get; set; }

    public ChiNhanh ChiNhanh { get; set; }
    public NhanVien NhanVien { get; set; }

    public List<ChiTietPhieuXuat> ChiTietPhieuXuats { get; set; } = new List<ChiTietPhieuXuat>();
}


public class ChiTietPhieuXuat
{
    public string MaPX { get; set; }
    public string MaNL { get; set; }
    public string BatchID { get; set; }

    public decimal SoLuong { get; set; }

    public PhieuXuat PhieuXuat { get; set; }
    public NguyenLieu NguyenLieu { get; set; }
    public LoHang LoHang { get; set; }
}
public enum TrangThaiPhieuChuyen
{
    YeuCau,
    InTransit,
    HoanTat
}

public class PhieuChuyen
{
    public string MaPC { get; set; }

    public string MaCN_Xuat { get; set; }
    public string MaCN_Nhap { get; set; }

    public string MaNV { get; set; }
    public DateTime CreatedAt { get; set; }
    public bool IsDeleted { get; set; }

    public TrangThaiPhieuChuyen TrangThai { get; set; }

    public ChiNhanh ChiNhanhXuat { get; set; }
    public ChiNhanh ChiNhanhNhap { get; set; }
    public NhanVien NhanVien { get; set; }

    public List<ChiTietPhieuChuyen> ChiTietPhieuChuyens { get; set; } = new List<ChiTietPhieuChuyen>();
}
public class ChiTietPhieuChuyen
{
    public string MaPC { get; set; }
    public string MaNL { get; set; }

    public decimal SoLuong { get; set; }

    public PhieuChuyen PhieuChuyen { get; set; }
    public NguyenLieu NguyenLieu { get; set; }
}
public class KiemKho
{
    public string MaKK { get; set; }

    public string MaCN { get; set; }
    public string MaNV { get; set; }

    public DateTime NgayKiem { get; set; }

    public ChiNhanh ChiNhanh { get; set; }
    public NhanVien NhanVien { get; set; }

    public List<ChiTietKiemKho> ChiTietKiemKhos { get; set; } = new List<ChiTietKiemKho>();
}
public class ChiTietKiemKho
{
    public string MaKK { get; set; }
    public string MaNL { get; set; }

    public decimal SoLuongHeThong { get; set; }
    public decimal SoLuongThucTe { get; set; }
    public decimal ChenhLech { get; set; }

    public KiemKho KiemKho { get; set; }
    public NguyenLieu NguyenLieu { get; set; }
}
public class DieuChinhKho
{
    public string MaDC { get; set; }

    public string MaCN { get; set; }
    public string MaNL { get; set; }

    public decimal SoLuong { get; set; }

    public ChiNhanh ChiNhanh { get; set; }
    public NguyenLieu NguyenLieu { get; set; }
}
public class TonKho
{
    public string MaCN { get; set; }
    public string MaNL { get; set; }

    public decimal SoLuongTon { get; set; }

    public ChiNhanh ChiNhanh { get; set; }
    public NguyenLieu NguyenLieu { get; set; }
}
public class SyncLog
{
    public string SyncID { get; set; }

    public string Entity { get; set; }
    public string RecordID { get; set; }

    public string Status { get; set; }
}
public class ConflictLog
{
    public string ConflictID { get; set; }

    public string DataLocal { get; set; }
    public string DataServer { get; set; }
}
